package com.czxy.service;

import com.czxy.dao.UserMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @Date 2019/11/19
 *@author 遗憾就遗憾吧
 *@jdk 1.8
 */
@Service
public class UserService{

    @Resource
    private UserMapper userMapper;

}
