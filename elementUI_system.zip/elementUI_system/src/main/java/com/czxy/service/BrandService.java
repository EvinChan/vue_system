package com.czxy.service;


import com.czxy.dao.BrandMapper;
import com.czxy.dao.CategoryBrandMapper;
import com.czxy.pojo.Brand;
import com.czxy.pojo.CategoryBrand;
import com.czxy.povo.BaseResult;
import com.czxy.povo.BaseRequest;
import com.czxy.utils.CommonUtils;
import com.czxy.utils.UploadUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

/**
 * @Date 2019/11/19
 *@author 遗憾就遗憾吧
 *@jdk 1.8
 */
@Service
public class BrandService{

    @Resource
    private BrandMapper brandMapper;

    @Resource
    private CategoryBrandMapper categoryBrandMapper;

    public BaseResult findAll(BaseRequest baseRequest) {
        PageHelper.startPage(baseRequest.getPageNum() , baseRequest.getPageSize());
        Example ex = new Example(Brand.class);
        Example.Criteria criteria = ex.createCriteria();
        criteria.andLike("name" , "%"+baseRequest.getSearch()+"%");
        List<Brand> brands = brandMapper.selectByExample(ex);
        PageInfo<Brand> pageInfo = new PageInfo<>(brands);
        return new BaseResult(CommonUtils.SUCCESS , "成功" , pageInfo);
    }

    public BaseResult add(Brand brand) {
        brandMapper.insert(brand);
        //添加成功后， 会将添加的自增长id 返回到 brand对象中
        //进行 分类--品牌 中间表的赋值
        if (brand.getCategoryIds()!=null && !brand.getCategoryIds().isEmpty()) {
            for (String cid : brand.getCategoryIds().split(",")) {
                categoryBrandMapper.insert(new CategoryBrand(Integer.parseInt(cid), brand.getId()));
            }
        }

        return new BaseResult(CommonUtils.SUCCESS , "成功" , null);
    }

    public BaseResult upload(HttpServletRequest request , MultipartFile file , Brand brand) throws IOException {
        //上传图片
        String url = "";

        //判断file是否为null，前端是否传过来了 图片
        if (file == null){
            return new BaseResult(CommonUtils.SUCCESS , "失败" , url);
        }

        //将brand的id 赋值到 图片工具类的 tableBame 目录名称 ， 后面必须要加 /
        try {
            UploadUtils.upload(request , file , "brand_"+brand.getId());
            url = UploadUtils.getURL(file.getOriginalFilename() , "brand_"+brand.getId());
            return new BaseResult(CommonUtils.SUCCESS , "成功" , url);
        } catch (Exception e) {
            e.printStackTrace();
            return new BaseResult(CommonUtils.SUCCESS , "失败" , url);
        }
    }

    public void updateImage(Brand brand) {
        brandMapper.updateByPrimaryKeySelective(brand);
    }

    public BaseResult update(Brand brand) {
        //先修改本表的数据
        brandMapper.updateByPrimaryKeySelective(brand);
        //修改中间表  与分类表的对应数据

        //1.先删除，所有brand的id的数据
        categoryBrandMapper.deleteByBid(brand.getId());

        //2.在添加 brand 与 categroy的 id对应关系
        if (brand.getCategoryIds()!=null && !brand.getCategoryIds().isEmpty()) {
            for (String cid : brand.getCategoryIds().split(",")) {
                categoryBrandMapper.insert(new CategoryBrand(Integer.parseInt(cid), brand.getId()));
            }
        }
        return new BaseResult(CommonUtils.SUCCESS , "修改成功" , null);
    }
}
