package com.czxy.service;

import com.czxy.dao.AdminMapper;
import com.czxy.pojo.Admin;
import com.czxy.povo.BaseRequest;
import com.czxy.povo.BaseResult;
import com.czxy.utils.CommonUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.List;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/14
 * @jdk 1.8
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class AdminService {

    @Autowired
    private AdminMapper adminMapper;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    public BaseResult getAdmins(BaseRequest baseRequest){
        //进行分页 + 模糊查询
        PageHelper.startPage(baseRequest.getPageNum() , baseRequest.getPageSize());
        //进行 单表模糊的查询
        Example ex = new Example(Admin.class);
        ex.createCriteria().andLike("adminName" , "%"+baseRequest.getSearch()+"%");
        List<Admin> admins = adminMapper.selectByExample(ex);

        PageInfo<Admin> pageInfo = new PageInfo<>(admins);
        return new BaseResult(CommonUtils.SUCCESS , "成功" , pageInfo);
    }

    public BaseResult login(Admin admin) {
        //查询出 对应的
//        Admin findAdmin = adminMapper.login(admin.getAdminName());
//        //判断密码是否正确
//        if (findAdmin!=null && bCryptPasswordEncoder.matches(admin.getPassword(),findAdmin.getPassword())){
//            return new BaseResult(CommonUtils.SUCCESS , "成功" , findAdmin);
//        }
//        return new BaseResult(CommonUtils.FALL , "用户名或密码错误" , null);
        Admin thisAdmin = adminMapper.selectOne(admin);
        if (thisAdmin != null){
            return new BaseResult(CommonUtils.SUCCESS , "成功" , thisAdmin);
        }
        return new BaseResult(CommonUtils.FALL , "用户名或密码错误" , null);
    }

    public BaseResult findById(Integer id) {
        Admin admin = adminMapper.selectByPrimaryKey(id);
        return new BaseResult(CommonUtils.SUCCESS , "成功" , admin);
    }

    public BaseResult update(Admin admin) {
        adminMapper.updateByPrimaryKeySelective(admin);
        return new BaseResult(CommonUtils.SUCCESS , "成功" , null);
    }

    public BaseResult delAll(String ids) {
        for (String id : ids.split(",")) {
            adminMapper.deleteByPrimaryKey(id);
        }
        return new BaseResult(CommonUtils.SUCCESS , "成功" , null);
    }
}
