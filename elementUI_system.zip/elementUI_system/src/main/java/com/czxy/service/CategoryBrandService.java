package com.czxy.service;

import com.czxy.dao.CategoryBrandMapper;
import com.czxy.pojo.CategoryBrand;
import com.czxy.povo.BaseResult;
import com.czxy.utils.CommonUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Date 2019/11/19
 *@author 遗憾就遗憾吧
 *@jdk 1.8
 */
@Service
public class CategoryBrandService{

    @Resource
    private CategoryBrandMapper categoryBrandMapper;

    public BaseResult getAllCategoryById(Integer bid) {
        List<CategoryBrand> categoryBrands = categoryBrandMapper.getAllCategoryById(bid);
        return new BaseResult(CommonUtils.SUCCESS , "成功" , categoryBrands);
    }
}
