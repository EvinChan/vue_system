package com.czxy.service;

import com.czxy.dao.MenuMapper;
import com.czxy.dao.RoleMapper;
import com.czxy.pojo.Admin;
import com.czxy.pojo.Menu;
import com.czxy.pojo.Role;
import com.czxy.povo.BaseRequest;
import com.czxy.povo.BaseResult;
import com.czxy.utils.CommonUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.util.List;

import static java.awt.SystemColor.menu;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/14
 * @jdk 1.8
 */
@Service
public class RoleService {

    @Autowired
    private RoleMapper roleMapper;
    @Autowired
    private MenuMapper menuMapper;

    public BaseResult getAllRole(BaseRequest baseRequest){

        if (baseRequest.getPageNum() == null || baseRequest.getPageSize() ==null){
            List<Role> roles = roleMapper.selectAll();
            return new BaseResult(CommonUtils.SUCCESS , "成功" , roles);
        }

        //进行分页 + 模糊查询
        PageHelper.startPage(baseRequest.getPageNum() , baseRequest.getPageSize());
        //进行 单表模糊的查询
        Example ex = new Example(Role.class);
        ex.createCriteria().andLike("roleName" , "%"+baseRequest.getSearch()+"%");
//        List<Role> roles = roleMapper.selectByExample(ex);

        List<Role> roles = roleMapper.getAllRole(baseRequest.getSearch());

        PageInfo<Role> pageInfo = new PageInfo<Role>(roles);
        return new BaseResult(CommonUtils.SUCCESS , "成功" , pageInfo);
    }

    public BaseResult findAllMenus() {
        List<Menu> allMenus = menuMapper.findAllMenus();
        //需要使用一个递归方法，将最后一个 List<Menu>设置为 null
//        allMenus.set(0 ,setMenusNull(allMenus.get(0)));
        System.out.println(allMenus);

        return new BaseResult(CommonUtils.SUCCESS , "成功" , allMenus);
    }

    public BaseResult add(Role role) {
        roleMapper.insert(role);
        return new BaseResult(CommonUtils.SUCCESS , "成功" , null);
    }

    public BaseResult update(Role role) {
        roleMapper.updateByPrimaryKeySelective(role);
        return new BaseResult(CommonUtils.SUCCESS , "成功" , null);
    }


//    private Menu setMenusNull(Menu menu){
//        for (Menu thisMenu : menu.getMenus()) {
//            if (thisMenu.getMenus().size() <= 0){
//                thisMenu.setMenus(null);
//            }else{
//                setMenusNull(thisMenu);
//            }
//        }
//        return menu;
//    }
}
