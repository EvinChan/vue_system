package com.czxy.service;

import com.czxy.dao.CategoryMapper;
import com.czxy.pojo.Category;
import com.czxy.povo.BaseResult;
import com.czxy.povo.BaseRequest;
import com.czxy.utils.CommonUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Date 2019/11/19
 *@author 遗憾就遗憾吧
 *@jdk 1.8
 */
@Service
public class CategoryService{

    @Resource
    private CategoryMapper categoryMapper;

    public BaseResult findAll(BaseRequest baseRequest) {

        if (baseRequest.getPageSize() == null || baseRequest.getPageNum() == null){
            List<Category> categories = categoryMapper.selectAll();
            return new BaseResult(CommonUtils.SUCCESS , "成功" , categories);
        }

        PageHelper.startPage(baseRequest.getPageNum() , baseRequest.getPageSize());
        Example ex = new Example(Category.class);
        Example.Criteria criteria = ex.createCriteria();
        criteria.andLike("name" , "%"+baseRequest.getSearch()+"%");
        List<Category> categories = categoryMapper.selectByExample(ex);
        PageInfo<Category> pageInfo = new PageInfo<>(categories);
        return new BaseResult(CommonUtils.SUCCESS , "成功" , pageInfo);
    }
}
