package com.czxy.dao;

import com.czxy.pojo.CategoryBrand;
import com.czxy.povo.BaseResult;
import org.apache.ibatis.annotations.*;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

/**
 * @author admin
 */
@org.apache.ibatis.annotations.Mapper
public interface CategoryBrandMapper extends Mapper<CategoryBrand> {

    @Results({
            @Result(property = "categoryId" , column = "category_id"),
            @Result(property = "brandId" , column = "brand_id")
    })
    @Select("select * from category_brand where brand_id = #{bid}")
    List<CategoryBrand> getAllCategoryById(@Param("bid") Integer bid);

    @Delete("delete from category_brand where brand_id = #{bid}")
    void deleteByBid(@Param("bid") Integer bid);
}