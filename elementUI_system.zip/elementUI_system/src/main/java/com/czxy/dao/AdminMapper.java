package com.czxy.dao;

import com.czxy.pojo.Admin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/14
 * @jdk 1.8
 */
@Mapper
public interface AdminMapper extends tk.mybatis.mapper.common.Mapper<Admin> {

    @Select("select * from admin where Adminname = #{name}")
    Admin login(String name);
}
