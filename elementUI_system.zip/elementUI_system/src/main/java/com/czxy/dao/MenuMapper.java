package com.czxy.dao;

import com.czxy.pojo.Menu;
import com.czxy.pojo.Role;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/14
 * @jdk 1.8
 */
@Mapper
public interface MenuMapper extends tk.mybatis.mapper.common.Mapper<Menu> {


    @Results({
            @Result(property = "menuName" , column = "Menuname"),
            @Result(property = "Id" , column = "Id"),
            @Result(property = "menus" , many = @Many(select = "com.czxy.dao.MenuMapper.findByParentId"), column = "Id")
    })
    @Select("select * from menu where id = 1")
    List<Menu> findAllMenus();


    @Results({
            @Result(property = "menuName" , column = "Menuname"),
            @Result(property = "Id" , column = "Id"),
            @Result(property = "menus" , many = @Many(select = "com.czxy.dao.MenuMapper.findByParentId"), column = "Id")
    })
    @Select("select * from menu where ParentId = #{parentId}")
    List<Menu> findByParentId(@Param("parentId") Integer parentId);



    @Results({
            @Result(property = "menuName" , column = "Menuname"),
            @Result(property = "Id" , column = "Id")
    })
    @Select("select * from menu where Id in (select mid from role_menu where rid = #{rid})")
    List<Menu> getMenusByRid(@Param("rid")Integer rid);
}
