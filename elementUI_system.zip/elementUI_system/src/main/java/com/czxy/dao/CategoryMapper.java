package com.czxy.dao;

import com.czxy.pojo.Category;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author admin
 */
@org.apache.ibatis.annotations.Mapper
public interface CategoryMapper extends Mapper<Category> {
}