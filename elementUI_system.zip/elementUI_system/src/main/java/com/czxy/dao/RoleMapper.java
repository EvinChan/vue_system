package com.czxy.dao;

import com.czxy.pojo.Menu;
import com.czxy.pojo.Role;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/14
 * @jdk 1.8
 */
@Mapper
public interface RoleMapper extends tk.mybatis.mapper.common.Mapper<Role> {


    @Results({
            @Result(property = "Id" , column = "Id"),
            @Result(property = "roleName" , column = "Rolename"),
            @Result(property = "remark" , column = "Remark"),
            @Result(property = "menus" , many = @Many(select = "com.czxy.dao.MenuMapper.getMenusByRid") , column = "Id")
    })
    @Select("select * from role where Rolename like '%${search}%'")
    List<Role> getAllRole(@Param("search") String search);
}
