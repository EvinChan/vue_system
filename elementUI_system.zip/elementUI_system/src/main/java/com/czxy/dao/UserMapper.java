package com.czxy.dao;

import com.czxy.pojo.User;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author admin
 */
@org.apache.ibatis.annotations.Mapper
public interface UserMapper extends Mapper<User> {
}