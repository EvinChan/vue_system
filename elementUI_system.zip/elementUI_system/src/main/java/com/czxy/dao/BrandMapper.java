package com.czxy.dao;

import com.czxy.pojo.Brand;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author admin
 */
@org.apache.ibatis.annotations.Mapper
public interface BrandMapper extends Mapper<Brand> {
}