package com.czxy.controller;

import com.czxy.pojo.Role;
import com.czxy.povo.BaseRequest;
import com.czxy.povo.BaseResult;
import com.czxy.service.RoleService;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/14
 * @jdk 1.8
 */
@RestController
@RequestMapping("/role")
public class RoleController {

    @Autowired
    private RoleService roleService;

    @GetMapping
    public ResponseEntity<BaseResult> getAllRole(BaseRequest baseRequest){
        BaseResult br = roleService.getAllRole(baseRequest);
        return ResponseEntity.ok(br);
    }

    /**
     * @return 获取所有的 menus 授权对象
     */
    @GetMapping("/findAllMenus")
    public ResponseEntity<BaseResult> findAllMenus(){
        BaseResult br = roleService.findAllMenus();
        return ResponseEntity.ok(br);
    }

    @PostMapping
    public ResponseEntity<BaseResult> add(@RequestBody Role role){
        BaseResult br = roleService.add(role);
        return ResponseEntity.ok(br);
    }

    @PutMapping
    public ResponseEntity<BaseResult> update(@RequestBody Role role){
        BaseResult br = roleService.update(role);
        return ResponseEntity.ok(br);
    }



}
