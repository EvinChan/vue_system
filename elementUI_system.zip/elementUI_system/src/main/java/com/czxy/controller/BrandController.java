package com.czxy.controller;

import com.czxy.dao.CategoryBrandMapper;
import com.czxy.pojo.Brand;
import com.czxy.povo.BaseRequest;
import com.czxy.povo.BaseResult;
import com.czxy.service.BrandService;
import com.czxy.service.CategoryBrandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import sun.plugin2.util.NativeLibLoader;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/19
 * @jdk 1.8
 */
@RestController
@RequestMapping("/brand")
public class BrandController {

    @Autowired
    private BrandService brandService;

    @Autowired
    private CategoryBrandService categoryBrandService;

    @GetMapping
    public ResponseEntity<BaseResult> findAll(BaseRequest baseRequest){
        BaseResult br = brandService.findAll(baseRequest);
        return ResponseEntity.ok(br);
    }

    @PostMapping("/add")
    public ResponseEntity<BaseResult> add(MultipartFile file , HttpServletRequest request , Brand brand) throws IOException {
        brandService.add(brand);

        BaseResult br = brandService.upload(request,file,brand);
        //将返回的 br中data 的url地址，赋值给 brand对象地址的 image中
        brand.setImage(String.valueOf(br.getData()));

        //将当前brand对象的 image属性修改
        //修改数据库中的 image字段
        brandService.updateImage(brand);

        //br为 图片上传的结果， data为上传上图片的url路径
        return ResponseEntity.ok(br);
    }

    @GetMapping("/getAllCategoryById/{bid}")
    public ResponseEntity<BaseResult> getAllCategoryById(@PathVariable Integer bid){
        BaseResult br = categoryBrandService.getAllCategoryById(bid);
        return ResponseEntity.ok(br);
    }

    @PostMapping("/update")
    public ResponseEntity<BaseResult> update(MultipartFile file , HttpServletRequest request , Brand brand) throws IOException {
        //修改的 brand中是带有 id的，直接进行上传图片，之前的图片，不做删除处理
        BaseResult uploadBr = brandService.upload(request,file,brand);
        //判断br，如果有上传成功，就修改 brand中的image地址， 没有成功不修改，显示之前的图片
        if (uploadBr.getCode() == 1){
            brand.setImage(String.valueOf(uploadBr.getData()));
        }
        //进行brand的修改
        BaseResult br = brandService.update(brand);

        //br为 图片上传的结果， data为上传上图片的url路径
        return ResponseEntity.ok(br);
    }
}
