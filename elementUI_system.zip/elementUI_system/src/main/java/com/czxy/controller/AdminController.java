package com.czxy.controller;

import com.czxy.pojo.Admin;
import com.czxy.povo.BaseRequest;
import com.czxy.povo.BaseResult;
import com.czxy.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/14
 * @jdk 1.8
 */
@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping
    public ResponseEntity<BaseResult> getAdmins(BaseRequest baseRequest){
        //进行查询
        BaseResult br = adminService.getAdmins(baseRequest);
        return ResponseEntity.ok(br);
    }


    /**
     * @param admin 管理员登录
     * @return
     */
    @PostMapping("/login")
    public ResponseEntity<BaseResult> login(@RequestBody Admin admin , HttpServletRequest request){
        //进行查询
        BaseResult br = adminService.login(admin);

        request.getSession().setAttribute("loginAdmin" , br.getData());
        return ResponseEntity.ok(br);
    }

    /**
     * @param id 修改回显
     * @return
     */
    @GetMapping("/findById/{id}")
    public ResponseEntity<BaseResult> findById(@PathVariable Integer id){
        //进行查询
        BaseResult br = adminService.findById(id);
        return ResponseEntity.ok(br);
    }

    /**
     * @param admin 修改提交
     * @return
     */
    @PutMapping
    public ResponseEntity<BaseResult> update(@RequestBody Admin admin){
        BaseResult br = adminService.update(admin);
        return ResponseEntity.ok(br);
    }

    /**
     * @param Ids 批量删除
     * @return
     */
    @DeleteMapping("/delAll/{Ids}")
    public ResponseEntity<BaseResult> delAll(@PathVariable String Ids){
        BaseResult br = adminService.delAll(Ids);
        return ResponseEntity.ok(br);
    }

}
