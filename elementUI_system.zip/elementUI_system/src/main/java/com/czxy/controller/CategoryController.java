package com.czxy.controller;

import com.czxy.povo.BaseResult;
import com.czxy.povo.BaseRequest;
import com.czxy.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/19
 * @jdk 1.8
 */
@RestController
@RequestMapping("/category")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public ResponseEntity<BaseResult> findAll(BaseRequest baseRequest){
        BaseResult br = categoryService.findAll(baseRequest);
        return ResponseEntity.ok(br);
    }

}
