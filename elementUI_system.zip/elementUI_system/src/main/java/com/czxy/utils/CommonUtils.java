package com.czxy.utils;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/5
 */
public class CommonUtils {
    public static final Integer FALL = 0;

    public static final Integer SUCCESS = 1;
}
