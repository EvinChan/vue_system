package com.czxy.utils;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyun.oss.model.PutObjectResult;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.net.URL;
import java.util.Date;

/**
 * Created 路程很长 请别轻易失望 on 2019/11/15.
 *
 * @author 路程很长 请别轻易失望
 */
@RequestMapping("/upload")
@RestController
public class UploadController {

    @PostMapping
    public ResponseEntity<String> upload(HttpServletRequest request , MultipartFile file) throws IOException {
        UploadUtils.upload(request , file , "");
        return ResponseEntity.ok("上传成功");
    }

    @GetMapping("/jd")
    public ResponseEntity<Integer> getJD(HttpServletRequest request) throws InterruptedException {
        //获取进度
        Integer percent = UploadUtils.getPercent(request);
        System.out.println("我被访问了，进度"+percent);
        return ResponseEntity.ok(percent);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> delete(){
        UploadUtils.delete("强.jpg" , null);
        return ResponseEntity.ok("删除成功");
    }
}
