package com.czxy.povo;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/6
 * 请求类
 * 包含：
 * 1.分页的页数
 * 2.每页的条数
 */
public class BaseRequest {
    private Integer pageNum;
    private Integer pageSize;

    private String search;


    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    @Override
    public String toString() {
        return "BaseRequest{" +
                "pageNum=" + pageNum +
                ", pageSize=" + pageSize +
                ", search='" + search + '\'' +
                '}';
    }
}
