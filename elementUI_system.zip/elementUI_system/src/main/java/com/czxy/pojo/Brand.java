package com.czxy.pojo;

import javax.persistence.*;

@Table(name = "brand")
public class Brand {
    private static final long SERIAL_VERSION_UID = 3756592215063814727L;
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    @Column(name = "`name`")
    private String name;

    @Column(name = "image")
    private String image;

    @Column(name = "letter")
    private String letter;

    /**
     * 此属性，为类中另外添加的。数据库表中并没有。通用mapper方法出错
     * 设置 @Transient 注解，将此属性不与表中对应
     */
    @Transient
    private String categoryIds;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return image
     */
    public String getImage() {
        return image;
    }

    /**
     * @param image
     */
    public void setImage(String image) {
        this.image = image;
    }

    /**
     * @return letter
     */
    public String getLetter() {
        return letter;
    }

    /**
     * @param letter
     */
    public void setLetter(String letter) {
        this.letter = letter;
    }

    public String getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(String categoryIds) {
        this.categoryIds = categoryIds;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", name=").append(name);
        sb.append(", image=").append(image);
        sb.append(", letter=").append(letter);
        sb.append("]");
        return sb.toString();
    }
}