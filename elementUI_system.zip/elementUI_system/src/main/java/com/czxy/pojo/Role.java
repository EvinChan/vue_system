package com.czxy.pojo;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description  鏁版嵁搴撳搴旂殑瀹炰綋绫籠n * @Author  kedaya
 * @Date 2019-11-14 
 */

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table ( name ="role" )
public class Role  implements Serializable {

	private static final long SERIAL_VERSION_UID =  4468752821117725270L;

	/**
	 * 角色编号
	 */
	@Id
   	@Column(name = "Id" )
	@GeneratedValue(generator = "JDBC")
	private Integer Id;	

	/**
	 * 角色名字
	 */
   	@Column(name = "Rolename" )
	private String roleName;

	/**
	 * 菜单编号 1,2,3,4,5,6
	 */
   	@Column(name = "menuIds" )
	private String menuIds;	

	/**
	 * 备注
	 */
   	@Column(name = "Remark" )
	private String remark;

   	/*
   	* 一个角色下面有 多个权限
   	* */
   	private List<Menu> menus;

	public Integer getId() {
		return this.Id;
	}

	public void setId(Integer Id) {
		this.Id = Id;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getMenuIds() {
		return this.menuIds;
	}

	public void setMenuIds(String menuIds) {
		this.menuIds = menuIds;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public List<Menu> getMenus() {
		return menus;
	}

	public void setMenus(List<Menu> menus) {
		this.menus = menus;
	}
}
