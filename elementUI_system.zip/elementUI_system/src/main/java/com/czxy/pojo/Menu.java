package com.czxy.pojo;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description  鏁版嵁搴撳搴旂殑瀹炰綋绫籠n * @Author  kedaya
 * @Date 2019-11-14 
 */

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table ( name ="menu" )
public class Menu  implements Serializable {

	private static final long SERIAL_VERSION_UID =  7928303918416035882L;

	/**
	 * 菜单编号
	 */
	@Id
   	@Column(name = "Id" )
	@GeneratedValue(generator = "JDBC")
	private Integer Id;	

	/**
	 * Menuname
	 */
   	@Column(name = "Menuname" )
	private String menuName;

	/**
	 * 父菜单的编号;当它为0的时候，代表父菜单，其他值都是本表中的其他数据
	 */
   	@Column(name = "ParentId" )
	private Integer parentId;

   	@JsonInclude(JsonInclude.Include.NON_EMPTY)
   	private List<Menu> menus;


	public Integer getId() {
		return this.Id;
	}

	public void setId(Integer Id) {
		this.Id = Id;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public Integer getParentId() {
		return this.parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public List<Menu> getMenus() {
		return menus;
	}

	public void setMenus(List<Menu> menus) {
		this.menus = menus;
	}

	@Override
	public String toString() {
		return "Menu{" +
				"Id=" + Id +
				", menuName='" + menuName + '\'' +
				", parentId=" + parentId +
				", menus=" + menus +
				'}';
	}
}
