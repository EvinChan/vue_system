package com.czxy.pojo;

import javax.persistence.*;
import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description  鏁版嵁搴撳搴旂殑瀹炰綋绫籠n * @Author  kedaya
 * @Date 2019-11-14 
 */

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table ( name ="admin" )
public class Admin  implements Serializable {

	private static final long SERIAL_VERSION_UID =  2451818484186954771L;

	@Id
   	@Column(name = "Id" )
	@GeneratedValue(generator = "JDBC")
	private Integer Id;	

   	@Column(name = "Adminname" )
	private String adminName;

   	@Column(name = "Password" )
	private String password;	

   	@Column(name = "Email" )
	private String email;	

   	@Column(name = "Phone" )
	private String phone;

	/**
	 * 0禁用；1启用
	 */
   	@Column(name = "State" )
	private Integer state;

   	@Column(name = "roles")
   	private String roles;

	public Integer getId() {
		return this.Id;
	}

	public void setId(Integer Id) {
		this.Id = Id;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Integer getState() {
		return this.state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return "Admin{" +
				"Id=" + Id +
				", adminName='" + adminName + '\'' +
				", password='" + password + '\'' +
				", email='" + email + '\'' +
				", phone='" + phone + '\'' +
				", state=" + state +
				", roles='" + roles + '\'' +
				'}';
	}
}
