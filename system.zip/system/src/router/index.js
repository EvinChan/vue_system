import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/home',
    name: 'home',
    component: Home,
    children : [
      {
        path: '/home/adminList',
        name: 'adminList',
        component: () => import(/* webpackChunkName: "about" */ '../views/AdminList.vue')
      },
      {
        path: '/home/roleList',
        name: 'roleList',
        component: () => import(/* webpackChunkName: "about" */ '../views/RoleList.vue')
      },
      {
        path: '/home/upload',
        name: 'upload',
        component: () => import(/* webpackChunkName: "about" */ '../views/Upload.vue')
      },
      {
        path: '/home/categoryList',
        name: 'categoryList',
        component: () => import(/* webpackChunkName: "about" */ '../views/CategoryList.vue')
      },
      {
        path: '/home/brandList',
        name: 'brandList',
        component: () => import(/* webpackChunkName: "about" */ '../views/BrandList.vue')
      }
    ]
  },
  {
    path: '/about',
    name: 'about',
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    path: '/',
    name: 'login',
    component: () => import(/* webpackChunkName: "about" */ '../views/Login.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
