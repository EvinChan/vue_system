import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

Vue.config.productionTip = false


import axios from 'axios'
//与后端进行数据交换的时候带上cookie
axios.defaults.withCredentials=true; //共享 session
//设置axios访问的 默认路径
axios.defaults.baseURL = 'http://localhost:8090';
//设置全局 axios变量
Vue.prototype.$ajax = axios;

import ElementUI from 'element-ui';
Vue.use(ElementUI);

/* 导入element-ui样式*/
import 'element-ui/lib/theme-chalk/index.css'

// 导入reset.css
import '@/assets/reset.css';

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
