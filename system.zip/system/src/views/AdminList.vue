<template>
  <div>
        <div>
            <el-input v-model="baseRequest.search" placeholder="请输入搜索条件" @keyup.native="findAll()" style="width: 200px;"></el-input>

            <el-button type="danger" icon="el-icon-delete" style="margin-left: 5%;" @click="delAll()">批量删除</el-button>

        </div>
      <template>
        <el-table
            ref="multipleTable"
            :data="admins"
            tooltip-effect="dark"
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <el-table-column
            type="selection"
            width="55">
            </el-table-column>
            <el-table-column
            prop="id"
            label="编号"
            width="120">
            </el-table-column>
            <el-table-column
            prop="adminName"
            label="姓名"
            width="120">
            </el-table-column>
            <el-table-column
            prop="email"
            label="邮箱"
            width="180">
            </el-table-column>
            <el-table-column
            prop="phone"
            label="电话"
            width="120">
            </el-table-column>
            <el-table-column
                prop="state"
                label="状态"
                width="100"
                filter-placement="bottom-end">
                <template slot-scope="scope">
                    <el-tag
                     :type="scope.row.state == '0' ? 'danger' : 'success'"
                    disable-transitions>{{scope.row.state == '0' ? '禁用' : '正常'}}</el-tag>
                </template>
            </el-table-column>
            <el-table-column
            prop="zip"
            label="操作"
            width="120">
                <template slot-scope="scope">
                    <el-button type="primary" icon="el-icon-edit" @click="beforeUpdate(scope.row)">修改</el-button>  
                </template>
            </el-table-column> 
        </el-table>
      </template>
      <div style="margin-top: 5%; margin-left: 30%;">
        <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="baseRequest.pageNum"
            :page-sizes="[2,3,5,10]"
            :page-size="1"
            layout="total, sizes, prev, pager, next"
            :total="total">
        </el-pagination>
      </div>

      <div>
          <!-- 修改对话框 -->
            <el-dialog title="修改管理员" :visible.sync="dialogFormVisible">
              <el-form>
                <el-form-item label="名称">
                    <el-input v-model="updateAdmin.adminName"></el-input>
                </el-form-item>
                <el-form-item label="密码">
                    <el-input type="password" v-model="updateAdmin.password" show-password></el-input>
                </el-form-item>
                <el-form-item label="邮箱">
                    <el-input  v-model="updateAdmin.email"></el-input>
                </el-form-item>
                <el-form-item label="密码">
                    <el-input v-model="updateAdmin.phone"></el-input>
                </el-form-item>

                <el-form-item label="角色">
                     <el-checkbox-group v-model="checkList">
                        <el-checkbox :label="role.id" v-for="(role , index) in roles" :key="index">{{role.roleName}}</el-checkbox>
                    </el-checkbox-group>
                </el-form-item>

                <el-form-item label="状态">
                    <el-radio v-model="updateAdmin.state" label="0">禁用</el-radio>
                    <el-radio v-model="updateAdmin.state" label="1">正常</el-radio>
                </el-form-item>

              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="update()">确 定</el-button>
              </div>
            </el-dialog>
      </div>
  </div>
</template>

<script>
export default {
  data() { 
    return {
        admins : [] , //所有的管理员用户列表
        baseRequest : {
            pageNum : 1,
            pageSize : 2,
            search : ''
        }, //查询的条件
        multipleSelection : [] , //批量删除勾选
        total : 0 ,   //数据总条数
        updateAdmin : {} , //修改的admin
        dialogFormVisible :false , //对话框条件
        roles : [], // 所有角色
        checkList :[] , // 选择角色
    }
  },
  methods:{
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        async findAll(){
            //查询所有
            let {data} = await this.$ajax.get("/admin" , {
                params : this.baseRequest
            })

            console.log(data)
            this.admins = data.data.list;
            this.total = data.data.total;
        },
        async beforeUpdate(row){
            //修改
            // let {data} = await this.$ajax.get("/admin/findById/"+id);

            //深度克隆 , admin对象
            this.updateAdmin = JSON.parse(JSON.stringify(row));
            
            if(this.updateAdmin.state == 1){this.updateAdmin.state = "1"}else{this.updateAdmin.state = "0"}

            this.checkList = [];
            //进行 角色信息的 赋值
            let roles = this.updateAdmin.roles.split(",");

            // for(let i=0 ; i<roles.length ; i++){
            //     this.checkList[i] = parseInt(roles[i]);
            // }

            this.checkList = roles.map(s => parseInt(s));

            //查询所有的 角色信息
            this.$ajax.get("/role")
                .then(res => {
                    this.roles = res.data.data;
                })

            this.dialogFormVisible = true;//打开对话框
        },
        async update(){
            //进行 拼接角色 ; 使用toString方法，可以将数组转为 1,2,3 形式的String
            this.updateAdmin.roles = this.checkList.toString();
            // for(let i=0 ; i<this.checkList.length ; i++){
            //     this.updateAdmin.roles += this.checkList[i] + ","
            // }

            // this.updateAdmin.roles = this.updateAdmin.roles.substring(0, this.updateAdmin.roles.length-1);

            console.log(this.updateAdmin.roles);
            //进行修改提交
            let {data} = await this.$ajax.put("/admin" , this.updateAdmin);
            this.findAll();
            this.dialogFormVisible = false;
        },
        handleSizeChange(val) {
            //分页 条数
            this.baseRequest.pageSize = val;
            this.findAll();
        },
        handleCurrentChange(val) {
            this.baseRequest.pageNum = val;
            this.findAll();
        },
        async delAll(){
            //将勾选的 数据进行 字符串拼接
            let ids = ''
            for(let i=0 ; i<this.multipleSelection.length ; i++){
                ids += this.multipleSelection[i].id + ","
            }
            //将最后一个 , 去掉
            ids = ids.substring(0,ids.length);

            if(ids == ''){
                this.$message.error("没有勾选数据");
                return;
            }

            let {data} = await this.$ajax.delete("/admin/delAll/"+ids);

            this.findAll();
        }
  },
  created(){
      this.findAll();
  }
 }
</script>

<style>
</style>