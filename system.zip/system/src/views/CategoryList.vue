<template>
    <div>
        <div>
            <el-button type="success" @click="beforeAdd()" class="el-icon-circle-plus-outline" plain>添加</el-button>
            <i style="padding: 3%;"></i>
            <el-input v-model="pageRequest.search" @keyup.native="findAll()" placeholder="请输入内容进行搜索"
                style="width: 160px"></el-input>
        </div>
        <el-table :data="categorys" style="width: 100% ;" @selection-change="handleSelectionChange">
            <el-table-column type="selection">
            </el-table-column>
            <el-table-column prop="id" label="分类编号">
            </el-table-column>
            <el-table-column prop="name" label="分类名称">
            </el-table-column>
            <el-table-column prop="parentId" label="上一级分类">
            </el-table-column>
            <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="beforeUpdate(scope.row)">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
        <div align="center" style="margin-top: 3%;">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
                :current-page="pageRequest.pageNum" :page-sizes="[2, 3, 5, 10]" :page-size="2" :pager-count="5"
                layout="total, sizes, prev, pager, next , jumper" :total="total">
            </el-pagination>
        </div>

        <!-- 添加的对话框 -->
        <div>
            <!-- <el-dialog title="添加学生" :visible.sync="dialogFormVisible">
        <el-form>
            <el-form-item label="活动名称">
            <el-input v-model="addStudent.name" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="活动区域">
            <el-select v-model="addStudent.region" placeholder="请选择活动区域">
                <el-option label="区域一" value="shanghai"></el-option>
                <el-option label="区域二" value="beijing"></el-option>
            </el-select>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
        </div>
        </el-dialog> -->
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                pageRequest: {
                    pageNum: 1,
                    pageSize: 2,
                    search: ''
                },                      //查询的分页 和模糊条件
                multipleSelection: [], //复选框 选中赋值数组
                categorys: [], //所有的对象
                total: 0,  //分页的总条数
                dialogFormVisible: false,  //添加的对话框
            }
        },
        methods: {
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },
            async findAll() {
                let { data } = await this.$ajax.get("/category", {
                    params: this.pageRequest
                });
                this.categorys = data.data.list;
                this.total = data.data.total;
                console.log(data.data);
            },
            beforeUpdate(row) {
                console.log(123);
            },
            //分页的方法
            handleSizeChange(val) {
                this.pageRequest.pageSize = val;
                this.findAll();
            },
            handleCurrentChange(val) {
                this.pageRequest.pageNum = val;
                this.findAll();
            },
            //添加的方法
            async beforeAdd() {
                //查询出所有的老师进行 赋值

            }

        },
        created() {
            this.findAll();
        }
    }
</script>

<style>
</style>