<template>
  <div>
        <el-upload
            class="upload-demo"
            action="http://localhost:8090/upload"
            :on-progress="getProgress"
            :file-list="fileList"
            list-type="picture"
            name="file"
            :with-credentials="true"
            style="width:30%">
            <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <el-progress v-if="isTure" :text-inside="true" :stroke-width="26" :percentage="percentage" :color="customColors" style="width: 30%;"></el-progress>
  </div>
</template>

<script>
export default {
  data() { 
    return {
        fileList: [{name: 'food.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}, {name: 'food2.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}],
        customColors: [
          {color: '#f56c6c', percentage: 20},
          {color: '#e6a23c', percentage: 40},
          {color: 'rgb(33, 187, 207)', percentage: 60},
          {color: '#1989fa', percentage: 80},
          {color: 'rgb(81, 184, 81)', percentage: 100}
        ],  //颜色展示
        isTure : false ,  //是否展示 滚动条
        percentage : 0 , //滚动条数据

    }
  },
  methods:{
      getProgress(event, file, fileList){
        //将进度条打开
        this.isTure = true;
        //此方法的开始，将percentage赋值0
        this.percentage = 0;

        //访问后台，获取滚动条数据
        //每隔 0.1秒访问一次后台，获取一次进度条数据
        let time = setInterval( () =>{
            //调用 获取进度条的方法
            this.getJD();

            if(this.percentage >= 100){
                clearInterval(time);
                this.isTure = false;
                this.percentage = 0;
                return;
            }
        } , 100);
      },
      async getJD(){
        let {data} = await this.$ajax.get("/upload/jd");
        console.log(data);
        this.percentage = data;
      }
  },
 }
</script>

<style>
</style>
