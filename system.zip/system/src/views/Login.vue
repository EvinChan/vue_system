<template>
  <div>
        
        <el-form status-icon label-width="100px" style="width: 25%;margin-top: 15%;margin-left: 30%;" class="demo-ruleForm">
            <h1 style="text-align: center;margin-bottom: 10%;font-size: medium;margin-left: 15%;">管理员登录</h1>
        <el-form-item label="管理员账户">
            <el-input type="text" v-model="admin.adminName"></el-input>
        </el-form-item>
        <el-form-item label="密码">
            <el-input type="password" v-model="admin.password"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="login()">提交</el-button>
            <el-button>重置</el-button>
        </el-form-item>
        </el-form>
  </div>
</template>

<script>

export default {
  data() { 
    return {
        admin : {} , //登录的admin管理员账户
    }
  },
  methods:{
        async login(){
            let {data} = await this.$ajax.post("/admin/login" , this.admin);
            if(data.code == 1){
                this.$router.push("/home")
                this.$message({
                    showClose: true,
                    message: '登录成功',
                    type: 'success'
                });
            }else{
                this.$message({
                    showClose: true,
                    message: data.msg,
                    type: 'error'
                });
            }
        }
  },
 }
</script>

<style>
</style>