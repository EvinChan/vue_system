<template>
  <div>
        <div>
            <el-input v-model="baseRequest.search" placeholder="请输入搜索条件" @keyup.native="findAll()" style="width: 200px;"></el-input>

            <el-button type="success" round style="margin-left:5%" @click="beforeAdd()">新增</el-button>
        </div>
      <template>
        <el-table
            ref="multipleTable"
            :data="roles"
            tooltip-effect="dark"
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <el-table-column
            type="selection"
            width="55">
            </el-table-column>
            <el-table-column
            prop="id"
            label="角色编号"
            width="80">
            </el-table-column>
            <el-table-column
            prop="roleName"
            label="角色名称"
            width="120">
            </el-table-column>
            <el-table-column
            prop="remark"
            label="备注"
            width="180">
            </el-table-column>
            <el-table-column
            prop="zip"
            label="操作"
            width="120">
                <template slot-scope="scope">
                    <el-button type="primary" icon="el-icon-edit" @click="beforeUpdate(scope.row)">修改</el-button>
                </template>
            </el-table-column>
        </el-table>
      </template>
      <div style="margin-top: 2%; margin-left: 5%;">
        <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="baseRequest.pageNum"
            :page-sizes="[2,3,5,10]"
            :page-size="1"
            layout="total, sizes, prev, pager, next"
            :total="total">
        </el-pagination>
      </div>

      <div>
          <!-- 添加 -->
            <el-dialog title="修改" :visible.sync="dialogFormVisible">
              <el-form>
                <el-form-item label="角色名称">
                    <el-input v-model="role.roleName"></el-input>
                </el-form-item>
                <el-form-item label="角色备注">
                    <el-input type="text" v-model="role.remark"></el-input>
                </el-form-item>
                <!-- 树 -->
              <el-form-item>
                  <h1>授权:</h1>
                  <!-- <el-tree
                    :data="data"
                    show-checkbox
                    node-key="id"
                    ref="tree"
                    highlight-current
                    :props="defaultProps">
                  </el-tree> -->

                  <!-- 使用级联 -->
                  <div class="block">
                    <el-cascader
                      v-model="checkList"
                      :options="data"
                      :props="props"
                      filterable
                      clearable></el-cascader>
                  </div>

              </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="add()">确 定</el-button>
              </div>
            </el-dialog>
      </div>

      <div>
          <!-- 修改 -->
            <el-dialog title="添加角色" :visible.sync="dialogFormVisible2">
              <el-form>
                <el-form-item label="角色名称">
                    <el-input v-model="updateRole.roleName"></el-input>
                </el-form-item>
                <el-form-item label="角色备注">
                    <el-input type="text" v-model="updateRole.remark"></el-input>
                </el-form-item>
                <!-- 树 -->
              <el-form-item>
                  <h1>授权:</h1>
                  <el-tree
                    :data="data"
                    show-checkbox
                    node-key="id"
                    ref="tree"
                    highlight-current
                    :props="defaultProps"
                    :default-checked-keys="menus">
                  </el-tree>
              </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible2 = false">取 消</el-button>
                <el-button type="primary" @click="update()">确 定</el-button>
              </div>
            </el-dialog>
      </div>

  </div>
</template>

<script>
export default {
  data() { 
    return {
        roles : [] , //所有角色
        baseRequest : {
            pageNum : 1,
            pageSize : 2,
            search : ''
        }, //查询的条件
        total : 0,  //总条数
        role : {}, //添加的角色对象
        dialogFormVisible :false ,  //对话框
        data: [],
        defaultProps: {
          children: 'menus',
          label: 'menuName'
        },
        menus :[] , //修改角色时，默认选中的 树框
        updateRole : {} , //修改的角色对象
        dialogFormVisible2 : false , //修改对话框

        //使用级联
        props: { 
          multiple: true ,
          value : "id" ,
          children : "menus" ,
          label : "menuName"
        },
        checkList:[
        ],
        

    }
  },
  methods:{
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        async findAll(){
            let {data} = await this.$ajax.get("/role" , {
              params : this.baseRequest
            });
            this.roles = data.data.list;
            this.total = data.data.total;
        },
        handleSizeChange(val) {
            //分页 条数
            this.baseRequest.pageSize = val;
            this.findAll();
        },
        handleCurrentChange(val) {
            this.baseRequest.pageNum = val;
            this.findAll();
        },
        async beforeAdd(){
            this.checkList = [];
            this.role = {};
            this.dialogFormVisible = true;
            this.getAllmenus();
        },
        async add(){
            //添加角色
            //getCheckedKeys方法，可以获取 数节点中被 选中的所有节点的 key
            // let keys = this.$refs.tree.getCheckedKeys();

            // let keys = this.$refs.cascader.getCheckedNodes();  //方法错误，没有此方法

            let keys = []; //获取级联 选择的最后一级的 id
            for(let index in this.checkList){
              let thisCheck = this.checkList[index];
              keys.push(thisCheck[thisCheck.length-1]);
            }
            
            console.log(keys);
            //将数组 转为 带有 , 的字符串
            this.role.menuIds = keys.toString();
            
            let {data} = await this.$ajax.post("/role" , this.role);

            this.findAll();
            this.dialogFormVisible = false;
        },
        beforeUpdate(row){
          //修改前的 初始化
          this.updateRole = JSON.parse(JSON.stringify(row));
          this.menus = [];
           
          //将树的 默认选中加入到 数组中
          if(this.updateRole.menuIds != undefined){
            this.menus = this.updateRole.menuIds.split(",").map(s => parseInt(s));
          }

          this.getAllmenus();

          this.dialogFormVisible2 = true;
        },
        async update(){
            //进行修改提交
            //getCheckedKeys方法，可以获取 数节点中被 选中的所有节点的 key
            let keys = this.$refs.tree.getCheckedKeys();
            this.updateRole.menuIds = keys.toString();

            let {data} = await this.$ajax.put("/role" , this.updateRole);

            if(data.code == 1){
              this.$message.success("修改成功");
              this.findAll();
              this.dialogFormVisible2 = false;
            }

        },
        async getAllmenus(){
            //访问后台 获取所有的  授权对象集合
            let {data} = await this.$ajax.get("/role/findAllMenus");
            console.log(data.data);
            //进行循环给 this.data赋值
            this.data = data.data;
        }
  },
  created(){
    this.findAll();
  }
 }
</script>

<style>
</style>