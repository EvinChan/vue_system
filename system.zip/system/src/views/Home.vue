<template>
  <div id="app">
      <el-container>
        <el-header style="height: 100px;">
            <h1 style="font-size: 45px;">
              JAVA High School
            </h1>
            <div style="color: seagreen;">
              <hr style="border:0;background-color:black;height:1px;width: 60%;margin-left: 20%;">
            </div>
        </el-header>
        <el-container>
          <el-aside width="200px">
              <el-menu
                :default-active="$route.path"
                :router="true"
                background-color="rgb(233, 238, 242)"
                style="height: 100%;">

                <el-submenu index="/home">
                  <template slot="title">
                    <i class="el-icon-location"></i>
                    <span>管理系统</span>
                  </template>
                    <el-menu-item index="/home/adminList">管理员列表</el-menu-item>
                    <el-menu-item index="/home/roleList">角色列表</el-menu-item>
                    <el-menu-item index="/home/categoryList">
                      <i class="el-icon-menu"></i>
                      <span slot="title">分类列表</span>
                    </el-menu-item>
                    <el-menu-item index="/home/brandList">
                      <i class="el-icon-menu"></i>
                      <span slot="title">品牌列表</span>
                    </el-menu-item>
                </el-submenu>
                <el-submenu index="/home2">
                  <template slot="title">
                    <i class="el-icon-location"></i>
                    <span>附加功能</span>
                  </template>
                    <el-menu-item index="/home/upload">图片上传</el-menu-item>
                </el-submenu>
              </el-menu>
          </el-aside>
          <el-main>
             <router-view></router-view>
          </el-main>
        </el-container>
      </el-container>
  </div>
</template>

<script>
import axios from 'axios';  //导入axios请求包
axios.defaults.baseURL = 'http://localhost:8090';  //java后台服务器的http地址

export default {
  data() { 
    return {

    }
  },
  methods:{

  },
 }
</script>

<style>

   /*
      找到html标签、body标签，和挂载的标签
      都给他们统一设置样式
   */
   html,body,#app,.el-container{
           /*设置内部填充为0，几个布局元素之间没有间距*/
           padding: 0px;
           /*外部间距也是如此设置*/
           margin: 0px;
           /*统一设置高度为100%*/
           height: 100%;
   }

  .el-header, .el-footer {
    background-color: rgb(233, 238, 242);
    color: #333;
    text-align: center;
    line-height: 90px;
  }
  
  /* .el-aside {
    background-color: #D3DCE6;
    color: #333;
    text-align: center;
  } */
  
  .el-main {
    background-color: white;
    color: #333;
  }
</style>