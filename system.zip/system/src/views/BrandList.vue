<template>
    <div>
        <div>
            <el-button type="success" @click="beforeAdd()" class="el-icon-circle-plus-outline" plain>添加</el-button>
            <i style="padding: 3%;"></i>
            <el-input v-model="pageRequest.search" @keyup.native="findAll()" placeholder="请输入内容进行搜索"
                style="width: 160px"></el-input>
        </div>
        <el-table ref="multipleTable" :data="brands" tooltip-effect="dark" style="width: 100%"
            @selection-change="handleSelectionChange">
            <el-table-column type="selection"></el-table-column>
            <el-table-column prop="id" label="品牌编号"></el-table-column>
            <el-table-column prop="name" label="品牌名称"></el-table-column>
            <el-table-column  label="品牌图片">
                <template slot-scope="scope">
                    <img :src="scope.row.image" width="30%">
                </template>
            </el-table-column>
            <el-table-column prop="letter" label="品牌首字母"></el-table-column>
            <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button type="text" size="small" @click="beforeUpdate(scope.row)">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
        <div style="margin-top:3%;text-align:center">
            <el-pagination 
                @size-change="handleSizeChange" 
                @current-change="handleCurrentChange"
                :current-page="pageRequest.pageNum" 
                :page-sizes="[2, 3, 5, 10]" 
                :page-size="2"
                layout="total, sizes, prev, pager, next" 
                :total="total">
            </el-pagination>
        </div>

        <!-- 添加的对话框 -->
        <div>
            <el-dialog title="添加品牌" :visible.sync="dialogFormVisible">
                <el-form :model="addBrand" ref="addBrand">
                    <el-form-item label="品牌名称">
                        <el-input v-model="addBrand.name" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="品牌首字母">
                        <el-input v-model="addBrand.letter" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="添加图片" ref="uploadElement" prop="img">
                        <!-- 
                            添加图片上传：
                            设置:auto-upload="false" ； 关闭组件的默认自动上传
                            action ： 随便设置
                            :on-change="handleChange" : 当组件的图片修改时，调用函数方法，来判断图片的格式大小，并替换图片
                            :file-list="fileList" ： 展示图片列表
                         -->
                        <el-upload
                            class="upload-demo"
                            action="#"
                            accept="image/jpeg,image/jpg,image/png"
                            ref="upload"
                            :auto-upload="false"
                            :on-change="handleChange"
                            :file-list="fileList">
                            <el-button size="small" type="primary">选择文件</el-button>
                            <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过2MB</div>
                        </el-upload>
                    </el-form-item>
                    <el-form-item>
                        <el-select v-model="checkList" multiple placeholder="请选择">
                            <el-option
                                v-for="(category,index) in categorys"
                                :key="index"
                                :label="category.name"
                                :value="category.id">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="dialogFormVisible = false">取 消</el-button>
                    <el-button type="primary" @click="upload()">确 定</el-button>
                </div>
            </el-dialog>
        </div>

        <!-- 修改对话框 -->
        <div>
            <el-dialog title="修改品牌" :visible.sync="dialogFormVisible2">
                <el-form :model="addBrand" ref="addBrand">
                    <el-form-item label="品牌名称">
                        <el-input v-model="updateBrand.name" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="品牌首字母">
                        <el-input v-model="updateBrand.letter" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="修改图片:" ref="uploadElement" prop="img">
                        <h1 style="display: inline-block;font-size: 20px;">原图片:</h1>
                        <img :src="updateBrand.image" width="8%" style="display: inline-block;">

                        <h1 style="display: inline-block;font-size: 20px;margin-left: 10%;">选择图片:</h1>
                        <el-upload
                            class="upload-demo"
                            action="http://localhost:8090/brand/upload"
                            accept="image/jpeg,image/jpg,image/png"
                            ref="upload"
                            :auto-upload="false"
                            :on-change="handleChange"
                            :file-list="fileList"
                            style="display: inline-block;margin-left: 2%;">
                            <el-button size="small" type="primary">选择文件</el-button>
                            <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过2MB</div>
                        </el-upload>
                    </el-form-item>
                    <el-form-item  label="分类:">
                        <el-select v-model="checkList" multiple placeholder="请选择">
                            <el-option
                                v-for="(category,index) in categorys"
                                :key="index"
                                :label="category.name"
                                :value="category.id">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="dialogFormVisible2 = false">取 消</el-button>
                    <el-button type="primary" @click="update()">确 定</el-button>
                </div>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                pageRequest: {
                    pageNum: 1,
                    pageSize: 2,
                    search: ""
                }, //查询的分页 和模糊条件
                multipleSelection: [], //复选框 选中赋值数组
                brands: [], //所有的对象
                total: 0, //分页的总条数
                dialogFormVisible: false , //添加的对话框
                addBrand : {} , //添加的品牌对象
                categorys : [] , //所有分类对象
                checkList : [] ,  //下拉列表选择的 分类id
                fileList :  [] ,  //文件列表

                updateBrand : {} , //修改的brand对象
                dialogFormVisible2 : false , 

            };
        },
        methods: {
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },
            async findAll() {
                let { data } = await this.$ajax.get("/brand", {
                    params: this.pageRequest
                });
                this.brands = data.data.list;
                this.total = data.data.total;
            },
            //修改的方法
            async beforeUpdate(row) {
                //修改的回显
                //克隆对象
                this.updateBrand = JSON.parse(JSON.stringify(row));
                //通过当前的 id查询出当前 所拥有的分类
                let {data} = await this.$ajax.get("/brand/getAllCategoryById/"+row.id);
                
                this.fileList = [];
                this.checkList = [];
                //将当前 brand的分类id存储到 checkList中
                for(let index in data.data){
                    this.checkList.push(data.data[index].categoryId);
                }
                //打开修改框
                this.getAllCategorys();
                this.dialogFormVisible2 = true;
            },
            //修改的方法
            async update(){
                //进行修改的提交
                //将分类的 checkList 转为字符串 存入updateBrand的categroyIds中
                this.updateBrand.categoryIds = this.checkList.toString();

                //将各项数据存入到，formData中
                let fd = new FormData();
                //存入图片
                if(this.fileList.length != 0){
                    fd.append("file" , this.fileList[0].raw);
                }
                fd.append("id" , this.updateBrand.id);
                fd.append("name" , this.updateBrand.name);
                fd.append("letter" , this.updateBrand.letter);
                fd.append("categoryIds" , this.updateBrand.categoryIds);

                //访问 服务器后台
                let {data} = await this.$ajax.post("/brand/update" , fd);

                if(data.code == 1){
                    this.$message.success(data.msg);
                }
                this.findAll();
                this.dialogFormVisible2 = false;
            },
            //分页的方法
            handleSizeChange(val) {
                this.pageRequest.pageSize = val;
                this.findAll();
            },
            handleCurrentChange(val) {
                this.pageRequest.pageNum = val;
                this.findAll();
            },
            //查询所有分类
            async getAllCategorys(){
                //查询所有的分类
                let {data} = await this.$ajax.get("/category");
                this.categorys = data.data;
            },
            //添加的方法
            async beforeAdd() {
                this.getAllCategorys();

                this.addBrand = {};
                this.checkList = [];
                this.dialogFormVisible = true;
            },
            //图片方法
            //图片进行修改的方法
            handleChange(file, fileList) {
                let bo = this.beforeAvatarUpload(file);
                if(!bo){
                    //图片不符合规范
                    this.fileList = [];     //图片列表赋值为空
                    return;
                }
                //如果图片符合 规范，将之前的图片剪切，覆盖掉
                this.fileList = fileList.slice(-1);
            },
            //图片判断，大小
            beforeAvatarUpload(file) {
                const isJPG = file.raw.type == 'image/jpeg';
                const isLt2M = file.size / 1024 / 1024 < 2;

                if (!isJPG) {
                    this.$message.error('上传头像图片只能是 JPG 格式!');
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                return isJPG && isLt2M;
            },
            //添加方法
            async upload(){
                //将下拉框 选择的分类id，拼接成字符串，赋值给 addBrand对象中
                this.addBrand.categoryIds = this.checkList.toString();

                //上传图片 + 表单数据一起传给后台
                let fd = new FormData();
                //判断是否有文件
                if(this.fileList.length != 0){
                    fd.append("file" , this.fileList[0].raw);
                }
                //添加格外的表单基本数据
                fd.append("name" , this.addBrand.name);
                fd.append("letter" , this.addBrand.letter);
                fd.append("categoryIds" , this.addBrand.categoryIds);

                //必须使用 post请求，因为是原生的 数据提交
                let {data} = await this.$ajax.post("/brand/add" , fd);

                this.findAll();
                this.dialogFormVisible = false;
            },
        },
        created() {
            this.findAll();
        }
    };
</script>

<style>
</style>